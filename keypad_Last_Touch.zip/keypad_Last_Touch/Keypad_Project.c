
// LCD module connections
sbit LCD_RS at RC4_bit;
sbit LCD_EN at RC5_bit;
sbit LCD_D4 at RC0_bit;
sbit LCD_D5 at RC1_bit;
sbit LCD_D6 at RC2_bit;
sbit LCD_D7 at RC3_bit;
sbit LCD_RS_Direction at TRISC4_bit;
#define LCD_EN_Direction at TRISC_REG.Register_Bits.Bit5;
sbit LCD_D4_Direction at TRISC0_bit;
sbit LCD_D5_Direction at TRISC1_bit;
sbit LCD_D6_Direction at TRISC2_bit;
sbit LCD_D7_Direction at TRISC3_bit;
// End LCD module connections

char keypadPort at PORTD;
unsigned short kp, pos = 7;
char old_pass[5] = {49, 50, 51, 52, 53};
char new_pass[5];
unsigned short index = 0;









void main() {







}