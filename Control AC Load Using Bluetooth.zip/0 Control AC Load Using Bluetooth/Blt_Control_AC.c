
char value;

void main() {
    UART1_Init(9600);
    TRISD &= ~(3 << 0);
    PORTD &= ~(3 << 0);
    while(1){
         if(UART1_Data_Ready() == 1){
            value = UART1_Read();
            if(value == 'a'){
               RD0_bit = 1;
               UART1_Write_Text("\r");
               UART1_Write_Text("Lamp one is opened\r");
            }
            else if(value == 'b'){
               PORTD &= ~(1 << 0);
               UART1_Write_Text("\r");
               UART1_Write_Text("Lamp one is closed\r");
            }
            else if(value == 'c'){
               PORTD |= (1 << 1);
               UART1_Write_Text("\r");
               UART1_Write_Text("Lamp two is opened\r");
            }
            else if(value == 'd'){
               PORTD &= ~(1 << 1);
               UART1_Write_Text("\r");
               UART1_Write_Text("Lamp two is closed\r");
            }
         }
    }
}