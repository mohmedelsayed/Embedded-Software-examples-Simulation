
char value;

void Robot_Forward(void);
void Robot_Backward(void);
void Robot_TurnLeft(void);
void Robot_TurnRight(void);
void Robot_Stop(void);

void main() {
    UART1_Init(9600);
    TRISD &= ~(15 << 0);
    PORTD &= ~(15 << 0);
    while(1){
         if(UART1_Data_Ready() == 1){
            value = UART1_Read();
            if(value == 'a'){
               Robot_Forward();
               UART1_Write_Text("\r");
               UART1_Write_Text("Robot go forward\r");
            }
            else if(value == 'b'){
               Robot_Backward();
               UART1_Write_Text("\r");
               UART1_Write_Text("Robot go backward\r");
            }
            else if(value == 'c'){
               Robot_TurnRight();
               UART1_Write_Text("\r");
               UART1_Write_Text("Robot go right\r");
            }
            else if(value == 'd'){
               Robot_TurnLeft();
               UART1_Write_Text("\r");
               UART1_Write_Text("Robot go left\r");
            }
            else if(value == 'e'){
               Robot_Stop();
               UART1_Write_Text("\r");
               UART1_Write_Text("Robot stop\r");
            }
         }
    }
}

void Robot_Forward(void){PORTD = 0x05;}
void Robot_Backward(void){PORTD = 0x0A;}
void Robot_TurnLeft(void){PORTD = 0x09;}
void Robot_TurnRight(void){PORTD = 0x06;}
void Robot_Stop(void){PORTD = 0x00;}