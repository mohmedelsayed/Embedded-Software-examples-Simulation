// LCD module connections
sbit LCD_RS at RC4_bit;
sbit LCD_EN at RC5_bit;
sbit LCD_D4 at RC0_bit;
sbit LCD_D5 at RC1_bit;
sbit LCD_D6 at RC2_bit;
sbit LCD_D7 at RC3_bit;

sbit LCD_RS_Direction at TRISC4_bit;
sbit LCD_EN_Direction at TRISC5_bit;
sbit LCD_D4_Direction at TRISC0_bit;
sbit LCD_D5_Direction at TRISC1_bit;
sbit LCD_D6_Direction at TRISC2_bit;
sbit LCD_D7_Direction at TRISC3_bit;
// End LCD module connections

unsigned int val1, val2, val3;
char val1_txt[7], val2_txt[7], val3_txt[7];

void main() {
    Lcd_Init();
    ADC_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    Lcd_Out(1,1,"Val : ");
    Lcd_Out(2,1,"Val : ");
    Lcd_Out(3,1,"Val : ");
    while(1){
         val1 = ADC_Read(0);
         val1 = (val1 * 500) / 1024;
         
         val2 = ADC_Read(1);
         val3 = ADC_Read(2);
         IntToStr(val1, val1_txt);
         IntToStr(val2, val2_txt);
         IntToStr(val3, val3_txt);
         Lcd_Out(1,7, val1_txt);
         Lcd_Out(2,7, val2_txt);
         Lcd_Out(3,7, val3_txt);
    }
}